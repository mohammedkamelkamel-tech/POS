package com.imecatro.demosales.data.clients.mappers

import com.imecatro.demosales.data.clients.model.ClientRoomEntity
import com.imecatro.demosales.data.clients.model.PurchaseRoomEntity
import com.imecatro.demosales.domain.clients.model.ClientDomainModel
import com.imecatro.demosales.domain.clients.model.PurchaseDomainModel


internal fun ClientRoomEntity.toDomain(): ClientDomainModel {
    return ClientDomainModel(
        id = id,
        name = name,
        phoneNumber = this.phone?:"",
        shipping = this.address?:"",
        avatarUri = this.imageUri?.ifEmpty { null },
        latitude = this.latitude,
        longitude = this.longitude,
        accumulatedPurchases = this.accumulatedPurchases,
        isFavorite = this.isFavorite
    )
}


internal fun PurchaseRoomEntity.toDomain(): PurchaseDomainModel {
    return PurchaseDomainModel(
        id = id,
        purchaseNumber = purchaseNumber,
        clientId = clientId,
        description = description,
        amount = amount,
        date = date
    )
}