package com.imecatro.demosales.ui.sales.list.views

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.imecatro.demosales.ui.sales.R
import com.imecatro.demosales.ui.sales.list.model.SaleOnListUiModel
import com.imecatro.demosales.ui.sales.list.model.StatusFilterUiModel
import com.imecatro.demosales.ui.sales.list.viewmodel.SalesListViewModel
import com.imecatro.demosales.ui.theme.common.SearchTopBar
import com.imecatro.demosales.ui.theme.common.download
import com.imecatro.demosales.ui.theme.common.formatAsCurrency
import com.imecatro.demosales.ui.theme.common.open
import com.imecatro.demosales.ui.theme.common.share
import com.imecatro.demosales.ui.theme.dialogs.PuntroSalesIcons
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true)
@Composable
fun SalesListComposable(
    list: List<SaleOnListUiModel> = fakelist,
    todayTotal: Double = 0.0,
    statusList: List<StatusFilterUiModel> = emptyList(),
    onStatusFilterChecked: (StatusFilterUiModel) -> Unit = {},
    itemsSelectedQty: Int = 0, // The amount of items selected in the list
    showDownloadOptions: Boolean = false,
    onHideDownloadOptions: () -> Unit = {},
    onDownloadClicked: () -> Unit = {},
    onSelectAllChecked: (Boolean) -> Unit = {}, // for selection all items
    allSelected: Boolean = false,
    onCardSelected: (id: Long) -> Unit = {},
    onCardClicked: (id: Long?) -> Unit = {},
    onShowSalesMetrics: () -> Unit = {},
    onAddNewSale: () -> Unit = {},
    searchQuery: String = "",
    onSearchQueryChange: (String) -> Unit = {},
    onOpenFulfillmentPlan: () -> Unit = {}
) {

    val scrollState = rememberLazyListState()

    var dateFilter by remember { mutableStateOf(false) }

    var statusFilter by remember { mutableStateOf(false) }

    var showFilters by remember { mutableStateOf(false) }

    Scaffold(floatingActionButton = {


        FloatingActionButton(
            onClick = { onAddNewSale() },
        ) {
            Row(Modifier.padding(10.dp, 0.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.ShoppingCart, contentDescription = null)
                AnimatedVisibility(!scrollState.isScrollInProgress) {
                    Spacer(modifier = Modifier.size(5.dp))
                    Text(stringResource(R.string.btn_new_sale))
                }
            }
        }

    }, topBar = {
        val windowInsets = TopAppBarDefaults.windowInsets

        Column(modifier = Modifier.windowInsetsPadding(windowInsets)) {
            AnimatedVisibility(visible = showDownloadOptions) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onHideDownloadOptions) {
                            Icon(Icons.Default.Close, null)
                        }
                        Text("$itemsSelectedQty")
                        Spacer(Modifier.weight(1f))

                        FilledIconButton(
                            onClick = onDownloadClicked,
                            enabled = itemsSelectedQty > 0
                        ) {
                            Icon(painterResource(R.drawable.filetype_csv), "Download")
                        }
                        Spacer(modifier = Modifier.size(10.dp))
                    }

                    Row(
                        Modifier.wrapContentSize(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(allSelected, onCheckedChange = { onSelectAllChecked(it) })
                        Text(stringResource(R.string.txt_select_all))
                    }
                }
            }
            AnimatedVisibility(!showDownloadOptions) {
                SearchTopBar(
                    title = stringResource(R.string.txt_sales_list_tittle),
                    query = searchQuery,
                    onQueryChange = onSearchQueryChange,
                    onSearchAction = { },
                    onClearSearchBar = { onSearchQueryChange("") },
                    placeholder = stringResource(R.string.txt_placeholder_search),
                    extraActions = {
                        FilledIconButton(onClick = onOpenFulfillmentPlan) {
                            Icon(
                                painter = painterResource(R.drawable.ic_fulfillment_plan_24),
                                contentDescription = stringResource(R.string.fulfillment_title)
                            )
                        }
                        IconButton(onClick = { showFilters = !showFilters }) {
                            Icon(
                                painter = painterResource(PuntroSalesIcons.filter),
                                contentDescription = "Filters",
                                tint = if (showFilters)
                                    MaterialTheme.colorScheme.primary
                                else
                                    MaterialTheme.colorScheme.onSurface
                            )
                        }

                        IconButton(onClick = { onCardSelected(0) }) {
                            Icon(
                                painter = painterResource(PuntroSalesIcons.check),
                                contentDescription = "Export CSV"
                            )
                        }
                    }
                )
            }
            AnimatedVisibility(visible = showFilters) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 15.dp)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                ) {
                    FilterChip(
                        onClick = { statusFilter = true },
                        label = {
                            Text(stringResource(R.string.txt_filter_state))
                        },
                        selected = statusList.any { it.isChecked },
                        leadingIcon = {
                            if (statusList.any { it.isChecked }) {
                                Icon(Icons.Filled.Done, null)
                            } else {
                                Icon(Icons.Filled.ArrowDropDown, null)
                            }
                        }
                    )

                }
            }
        }

    }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(innerPadding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth(),
                state = scrollState,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    ListItem(
                        headlineContent = {
                            Text(stringResource(R.string.txt_sales_list))
                        },
                        supportingContent = {
                            Text(stringResource(R.string.txt_sales_list_description))
                        },
                        trailingContent = {
                            TextButton(onClick = { onShowSalesMetrics() }) {
                                Text(todayTotal.formatAsCurrency())
                                Spacer(modifier = Modifier.size(5.dp))
                                Icon(painterResource(R.drawable.ic_graph_up), null)
                            }
                        })
                    HorizontalDivider()
                }
                items(list) { sale ->
                    CardOfSaleComposable(
                        sale = sale,
                        onLongClicked = { onCardSelected(sale.id) },
                        onCardClicked = { onCardClicked(sale.id) }
                    )
                }
            }


            if (dateFilter)
                ModalBottomSheet(onDismissRequest = { dateFilter = false }) {
                    Text(text = "Any time")
                    Text(text = "One week ago")
                    ListItem(leadingContent = {
                        RadioButton(selected = true, onClick = {})
                    }, headlineContent = {
                        Text(text = "One month ago")
                    })
                    TextButton(onClick = { /*TODO*/ }) {
                        Text(text = "Custom Range")
                    }
                }

            if (statusFilter)
                ModalBottomSheet(onDismissRequest = { statusFilter = false }) {
                    LazyColumn {
                        items(statusList) { status ->
                            ListItem(
                                leadingContent = {
                                    Checkbox(
                                        checked = status.isChecked,
                                        onCheckedChange = { onStatusFilterChecked(status) })
                                },
                                headlineContent = {
                                    Text(text = stringResource(status.text))
                                },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                            )
                        }
                    }
                }
        }
    }
}


private val fakelist = listOf(
    SaleOnListUiModel(0, "Named", "30/01/2023", 20.0, "pending", Color.Red),
    SaleOnListUiModel(1, "Someone", "30/01/2023", 20.0, "pending", Color.Gray)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesListComposableStateImpl(
    salesListViewModel: SalesListViewModel,
    onOpenFulfillmentPlan: () -> Unit = {},
    onNavigate: (Long?) -> Unit
) {

    //List
    val listUiState by salesListViewModel.salesListUiState.collectAsState()
    // Filters
    val statusFilterUiState by salesListViewModel.statusFilterState.collectAsState()
    // Reports
    val reportState by salesListViewModel.reportState.collectAsState()

    val showOptions = listUiState.any { it.isSelected } || reportState.enableSelection

    var showReports by remember { mutableStateOf(false) }

    var showGraph by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()

    val metricsState by salesListViewModel.metrics.collectAsStateWithLifecycle()

    val searchQuery by salesListViewModel.searchQuery.collectAsStateWithLifecycle()

    SalesListComposable(
        list = listUiState,
        todayTotal = salesListViewModel.todayTotalAmount.collectAsStateWithLifecycle().value,
        onCardClicked = { id ->
            if (showOptions)
                salesListViewModel.onCardSelected(id ?: 0L)
            else
                onNavigate(id)
        },
        itemsSelectedQty = reportState.ids.size,
        onHideDownloadOptions = { salesListViewModel.onClearSelections() },
        showDownloadOptions = showOptions,
        onDownloadClicked = { salesListViewModel.onDownloadCsv() },
        onSelectAllChecked = { salesListViewModel.onSelectAllSales(it) },
        allSelected = reportState.allSelected,
        onCardSelected = { salesListViewModel.onCardSelected(it) },
        onStatusFilterChecked = { salesListViewModel.onStatusFilterChange(it) },
        onShowSalesMetrics = { showGraph = true },
        statusList = statusFilterUiState,
        onAddNewSale = { onNavigate(null) },
        searchQuery = searchQuery,
        onSearchQueryChange = { salesListViewModel.onSearchQueryChange(it) },
        onOpenFulfillmentPlan = onOpenFulfillmentPlan
    )

    LaunchedEffect(reportState) {
        if (reportState.salesFile != null) {
            scope.launch { showReports = true }
        }
    }

    val context = LocalContext.current

    if (showReports)
        ModalBottomSheet(onDismissRequest = {
            salesListViewModel.onReportSent()
            showReports = false
        }) {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = {
                        reportState.salesFile?.open(context)
                    }) {
                        Text(stringResource(R.string.txt_sales_report))
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    IconButton(onClick = {
                        reportState.salesFile?.share(context)
                    }) { Icon(Icons.Default.Share, null) }

                    IconButton(onClick = {
                        reportState.salesFile?.download(context)
                    }) { Icon(painterResource(R.drawable.download), null) }

                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = {
                        reportState.groupedProductsFile?.open(context)
                    }) {
                        Text(stringResource(R.string.txt_products_report))
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    IconButton(onClick = {
                        reportState.groupedProductsFile?.share(context)
                    }) { Icon(Icons.Default.Share, null) }
                    IconButton(onClick = {
                        reportState.groupedProductsFile?.download(context)
                    }) { Icon(painterResource(R.drawable.download), null) }

                }
            }
        }

    if (showGraph) {
        ModalBottomSheet(
            onDismissRequest = { showGraph = false }
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 20.dp)
            ) {
                SalesGraphBottomSheetContent(
                    salesMetrics = metricsState
                )
            }
        }
    }
}
