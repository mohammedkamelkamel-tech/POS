package com.imecatro.products.ui.list.viewmodels

import androidx.lifecycle.viewModelScope
import com.imecatro.demosales.domain.products.model.ProductDomainModel
import com.imecatro.demosales.domain.products.model.ProductStockDomainModel
import com.imecatro.demosales.domain.products.repository.ProductsRepository
import com.imecatro.demosales.domain.products.usecases.ExportProductsCsvUseCase
import com.imecatro.demosales.domain.products.usecases.GetAllCategoriesUseCase
import com.imecatro.demosales.domain.products.usecases.IsCatalogPublishedUseCase
import com.imecatro.demosales.ui.theme.architect.BaseViewModel
import com.imecatro.demosales.ui.theme.architect.ErrorUiModel
import com.imecatro.products.ui.list.mappers.toProductUiModel
import com.imecatro.products.ui.list.model.CategoriesFilter
import com.imecatro.products.ui.list.model.ProductUiModel
import com.imecatro.products.ui.list.uistate.ListProductsUiState
import com.imecatro.products.ui.list.uistate.OrderedFilterState
import com.imecatro.products.ui.list.uistate.checkElement
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProductsViewModel @Inject constructor(
    private val productsRepository: ProductsRepository,
    private val getAllCategoriesUseCase: GetAllCategoriesUseCase,
    private val exportProductsCsvUseCase: ExportProductsCsvUseCase,
    private val isCatalogPublishedUseCase: IsCatalogPublishedUseCase,
    private val iODispatcher: CoroutineDispatcher = Dispatchers.IO
) : BaseViewModel<ListProductsUiState>(ListProductsUiState.idle) {

    private val _filtersState = MutableStateFlow(OrderedFilterState.filters)

    val filtersState: StateFlow<List<OrderedFilterState>> = _filtersState.asStateFlow()

    private val _categories: MutableStateFlow<List<CategoriesFilter>> =
        MutableStateFlow(emptyList())
    val categories: StateFlow<List<CategoriesFilter>> = _categories.asStateFlow()

    val productsList: StateFlow<List<ProductUiModel>> =
        productsRepository.getAllProducts()
            .onStart {
                updateState { copy(isFetchingProducts = true) }
            }
            .combine(filtersState) { products, filters ->
                // Filter by order
                applyOrderFilter(products, filters)
            }
            .combine(categories) { products, categories ->
                applyCategories(products, categories)
            }
            .map { it.toProductUiModel() }
            .combine(uiState) { products, report ->
                val ids = report.idsSelected
                products.map { product -> product.copy(isSelected = ids.contains(product.id)) }
            }
            .onEach {
                updateState { copy(isFetchingProducts = false) }
            }
            .flowOn(Dispatchers.Default) // Perform combine and map on Default dispatcher
            .catch {
                updateState { copy(isFetchingProducts = false) }

                val error = ErrorUiModel("", "No data")
                updateState { copy(errorFetchingProducts = error) }
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(), emptyList())

    private fun applyOrderFilter(
        products: List<ProductDomainModel>, // Assuming products from repository are Domain models
        filters: List<OrderedFilterState>
    ): List<ProductDomainModel> {
        val orderSelected: OrderedFilterState? = filters.firstOrNull { it.isChecked }

        return orderSelected?.let { selectedFilter ->
            when (selectedFilter.type) {
                OrderedFilterState.Type.NAME -> products.sortedBy { it.name?.lowercase() }
                OrderedFilterState.Type.PRICE -> products.sortedBy { it.price }
                OrderedFilterState.Type.STOCK -> products.sortedBy { it.stock.quantity }
                OrderedFilterState.Type.DATE -> products.sortedBy { it.id } // Consider if 'id' is appropriate for date sorting
                OrderedFilterState.Type.NAME_INVERSE -> products.sortedByDescending { it.name?.lowercase() }
                OrderedFilterState.Type.PRICE_INVERSE -> products.sortedByDescending { it.price }
                OrderedFilterState.Type.STOCK_INVERSE -> products.sortedByDescending { it.stock.quantity }
                OrderedFilterState.Type.DATE_INVERSE -> products.sortedByDescending { it.id } // Same consideration for 'id'
            }
        } ?: products // Return original list if no filter is selected or if orderSelected is null
    }

    private fun applyCategories(
        products: List<ProductDomainModel>, // Assuming products from repository are Domain models
        filters: List<CategoriesFilter>
    ): List<ProductDomainModel> {
        val categoriesChecked = filters.filter { it.isChecked }

        return if (categoriesChecked.isNotEmpty()) {
            products.filter { product ->
                categoriesChecked.any { category ->
                    product.category?.name == category.text ||
                            category.text.isEmpty() && product.category == null // for products with no category

                }
            }
        } else {
            products
        }
    }


    fun onSearchAction(query: String) {
        viewModelScope.launch(iODispatcher) {

            val list = productsRepository.searchProducts(query).first()
            updateState { copy(productsFiltered = list.toProductUiModel()) }
        }

    }

    fun onFilterChange(filter: OrderedFilterState) {
        viewModelScope.launch(iODispatcher) {
            _filtersState.update { it.checkElement(filter) }
        }
    }

    fun onFilterCategory(category: CategoriesFilter) {
        viewModelScope.launch(iODispatcher) {
            _categories.update { lst ->
                val index = lst.indexOf(category)
                lst.mapIndexed { i, categoryFilter ->
                    if (i == index)
                        categoryFilter.copy(isChecked = !categoryFilter.isChecked)
                    else
                        categoryFilter
                }
            }
        }
    }

    override fun onStart() {
        viewModelScope.launch {
            isCatalogPublishedUseCase.execute(Unit).onSuccess { catalog ->
                updateState { copy(isCatalogPublished = catalog != null) }
            }
        }
        viewModelScope.launch(Dispatchers.IO) {
            getAllCategoriesUseCase().collect { list ->
                val filter = list.map { CategoriesFilter(it.name, false) }

                val uncategorized = CategoriesFilter("", false) // for elements with no category
                _categories.update { filter.plus(uncategorized) }

            }
        }
    }

    fun onProductSelected(id: Long?) {
        if (id == null) {
            updateState { copy(enableSelection = true) }
            return
        }
        if (uiState.value.idsSelected.contains(id))
            updateState { copy(idsSelected = idsSelected.minus(id)) }
        else
            updateState { copy(idsSelected = idsSelected.plus(id)) }

        // Uncheck selection
        if (productsList.value.size != uiState.value.idsSelected.size) {
            updateState { copy(allSelected = false, enableSelection = false) }
        }

    }

    fun onSelectAllProducts(checked: Boolean) = viewModelScope.launch(Dispatchers.IO) {
        updateState { copy(allSelected = checked) }
        val currentIds: List<Long> = productsList.value.map { it.id ?: 0L }.filter { it != 0L }
        if (checked)
            updateState { copy(idsSelected = currentIds) }
        else
            updateState { copy(idsSelected = emptyList()) }
    }

    fun onClearSelections() = viewModelScope.launch(Dispatchers.IO) {
        updateState { copy(idsSelected = emptyList(), enableSelection = false) }
    }

    fun generateSampleData() = viewModelScope.launch(iODispatcher) {
        val samples = listOf(
            ProductDomainModel(
                id = null,
                name = "Apple",
                price = 1.5,
                currency = "$",
                unit = "pz",
                stock = ProductStockDomainModel(10.0, 0.8, emptyList()),
                details = "Fresh red apples",
                imageUri = null,
                category = null,
                barcode = "123456789"
            ),
            ProductDomainModel(
                id = null,
                name = "Milk",
                price = 2.0,
                currency = "$",
                unit = "pz",
                stock = ProductStockDomainModel(5.0, 1.2, emptyList()),
                details = "Whole milk 1L",
                imageUri = null,
                category = null,
                barcode = "987654321"
            ),
            ProductDomainModel(
                id = null,
                name = "Bread",
                price = 1.0,
                currency = "$",
                unit = "pz",
                stock = ProductStockDomainModel(20.0, 0.5, emptyList()),
                details = "White bread",
                imageUri = null,
                category = null,
                barcode = "456789123"
            )
        )
        samples.forEach { productsRepository.addProduct(it) }
    }

    fun onProcessProducts() = viewModelScope.launch {
        updateState { copy(isProcessingCatalog = true) }

        exportProductsCsvUseCase.execute {
            ids = uiState.value.idsSelected
        }.onSuccess { file ->
            updateState { copy(catalogFile = file, isProcessingCatalog = false) }
        }.onFailure {
            updateState { copy(isProcessingCatalog = false) }
        }
    }

    fun onCatalogShared() {
        updateState { copy(catalogFile = null) }
    }
}

