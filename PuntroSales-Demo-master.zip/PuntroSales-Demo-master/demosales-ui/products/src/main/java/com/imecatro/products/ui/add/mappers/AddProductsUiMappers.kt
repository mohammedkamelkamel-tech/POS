package com.imecatro.products.ui.add.mappers

import com.imecatro.demosales.domain.products.model.ProductCategoryDomainModel
import com.imecatro.demosales.domain.products.model.ProductDomainModel
import com.imecatro.demosales.domain.products.model.ProductStockDomainModel
import com.imecatro.products.ui.add.model.AddProductUiModel

//Design patter : Adapter
internal fun AddProductUiModel.toDomain(): ProductDomainModel {

    return ProductDomainModel(
        id = null,
        name = this.name,
        price = this.price?.toDouble() ?: 0.0,
        currency = this.currency,
        unit = this.unit,
        details = this.details,
        imageUri = this.imageUri?.toString(),
        stock = ProductStockDomainModel(quantity = this.stock.toDouble(), cost = 0.0, history = emptyList()),
        category = ProductCategoryDomainModel(name = this.category),
        barcode = this.barcode
    )
}
