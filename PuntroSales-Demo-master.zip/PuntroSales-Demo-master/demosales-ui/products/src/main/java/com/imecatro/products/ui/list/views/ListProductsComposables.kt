package com.imecatro.products.ui.list.views

import android.annotation.SuppressLint
import android.util.Log
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.imecatro.demosales.ui.theme.PuntroSalesDemoTheme
import com.imecatro.demosales.ui.theme.architect.UiStateHandler
import com.imecatro.demosales.ui.theme.common.SearchTopBar
import com.imecatro.demosales.ui.theme.common.download
import com.imecatro.demosales.ui.theme.common.open
import com.imecatro.demosales.ui.theme.common.share
import com.imecatro.demosales.ui.theme.dialogs.PuntroSalesIcons
import com.imecatro.products.ui.R
import com.imecatro.products.ui.list.components.ProductCardCompose
import com.imecatro.products.ui.list.model.CategoriesFilter
import com.imecatro.products.ui.list.model.ProductUiModel
import com.imecatro.products.ui.list.uistate.OrderedFilterState
import com.imecatro.products.ui.list.viewmodels.ProductsViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch


private const val TAG = "ListProductsComposables"


@OptIn(ExperimentalMaterial3Api::class, FlowPreview::class)
@Composable
fun ListOfProducts(
    list: List<ProductUiModel>,
    isLoading: Boolean = false,
    onSearchProduct: (String) -> Unit = {},
    searchList: List<ProductUiModel> = emptyList(),
    orderList: List<OrderedFilterState> = OrderedFilterState.filters,
    onCheckedChange: (OrderedFilterState) -> Unit = {},
    itemsSelectedQty: Int = 0, // The amount of items selected in the list
    showDownloadOptions: Boolean = false,
    onHideDownloadOptions: () -> Unit = {},
    onDownloadClicked: () -> Unit = {},
    onSelectAllChecked: (Boolean) -> Unit = {}, // for selection all item
    allSelected: Boolean = false,
    categories: List<CategoriesFilter> = emptyList(),
    onCategoryChecked: (CategoriesFilter) -> Unit = {},
    onEditCategoriesClicked: () -> Unit = {},
    onProductSelected: (Long?) -> Unit = {},
    onCardClicked: (Long?) -> Unit = {},
    onNavigateAction: () -> Unit = {},
    onGenerateSampleData: () -> Unit = {},
    isCatalogPublished: Boolean = false,
    onManagementAction: () -> Unit = {},
    banner: @Composable () -> Unit = {},
) {
    var text by rememberSaveable { mutableStateOf("") }
    //var expanded by rememberSaveable { mutableStateOf(false) }

    val scrollState = rememberLazyListState()
    var hasBanner by remember { mutableStateOf(false) }

    var showFilters by remember { mutableStateOf(false) }

    var orderedFilter by remember { mutableStateOf(false) }

    var categoriesFilter by remember { mutableStateOf(false) }

    val sheetState = rememberModalBottomSheetState(
        skipPartiallyExpanded = true,
        // Add this line to fix the error:
        confirmValueChange = { true }, // Add a default confirmValueChange lambda
    )

    LaunchedEffect(text) {
        snapshotFlow { text }
            .debounce(300)
            .collect {
                onSearchProduct(it)
            }
    }

    Scaffold(
        // Scaffold measures this slot separately, reserves its height for the list,
        // and places floating actions above it. Empty content consumes no space.
        bottomBar = {
            Box(Modifier.onSizeChanged { hasBanner = it.height > 0 }) { banner() }
        },
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (isCatalogPublished) {
                    SmallFloatingActionButton(
                        onClick = onManagementAction,
                        //containerColor = MaterialTheme.colorScheme.secondaryContainer,
                       // contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                        containerColor = Color(0xFF37C8AB),
                        contentColor = Color.White
                    ) {
                        Image(
                            painter = painterResource(R.drawable.ic_published_catalog),
                            contentDescription = "Manage Catalog",
                        )
                    }
                }

                if (list.isNotEmpty() || text.isNotEmpty()) {
                    ExtendedFloatingActionButton(
                        onClick = onNavigateAction,
                        icon = { Icon(Icons.Default.Add, null) },
                        text = { Text(stringResource(R.string.btn_new_product)) },
                        expanded = !scrollState.isScrollInProgress
                    )
                }
            }
        },
        topBar = {
            val windowInsets = TopAppBarDefaults.windowInsets

            Column(modifier = Modifier.windowInsetsPadding(windowInsets)) {
                AnimatedVisibility(visible = !showDownloadOptions) {
                    Column {
                        SearchTopBar(
                            title = stringResource(R.string.title_products_list),
                            query = text,
                            onQueryChange = { text = it },
                            onSearchAction = { onSearchProduct(text) },
                            onClearSearchBar = { text = "" },
                            extraActions = {
                                IconButton(onClick = { showFilters = !showFilters }) {
                                    Icon(
                                        painter = painterResource(R.drawable.filter_sorting),
                                        contentDescription = "Filters",
                                        tint = if (showFilters || categories.any { it.isChecked })
                                            MaterialTheme.colorScheme.primary
                                        else
                                            MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                IconButton(onClick = { onProductSelected(null) }) {
                                    Icon(
                                        painter = painterResource(PuntroSalesIcons.check),
                                        contentDescription = "Export CSV"
                                    )
                                }
                            }
                        )
                        AnimatedVisibility(visible = showFilters) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 15.dp)
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(20.dp),
                            ) {
                                FilterChip(
                                    onClick = { orderedFilter = true },
                                    label = {
                                        Text(stringResource(R.string.chip_order_by))
                                    },
                                    selected = orderList.any { it.isChecked },
                                    leadingIcon = {
                                        Icon(painterResource(R.drawable.filter_sorting), null)
                                    }
                                )

                                FilterChip(
                                    onClick = { categoriesFilter = true },
                                    label = {
                                        Text(stringResource(R.string.tittle_categories))
                                    },
                                    selected = categories.any { it.isChecked },
                                    leadingIcon = {
                                        Icon(Icons.Default.KeyboardArrowDown, null)
                                    }
                                )
                            }
                        }
                    }
                }
                AnimatedVisibility(visible = showDownloadOptions) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = onHideDownloadOptions) {
                                Icon(Icons.Default.Close, null)
                            }
                            Text("$itemsSelectedQty")
                            Spacer(Modifier.weight(1f))

                            FilledIconButton(
                                onClick = onDownloadClicked,
                                enabled = itemsSelectedQty > 0
                            ) {
                                Icon(painterResource(R.drawable.file_earmark_richtext), "Download")
                            }
                            Spacer(modifier = Modifier.size(10.dp))
                        }

                        Row(
                            Modifier.wrapContentSize(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(allSelected, onCheckedChange = { onSelectAllChecked(it) })
                            Text(stringResource(R.string.txt_select_all))
                        }
                    }
                }
            }

        }) { innerPadding ->
        if (!isLoading && list.isEmpty() && text.isEmpty()) {
            EmptyProductsState(
                onAddProductClicked = onNavigateAction,
                onGenerateSampleDataClicked = onGenerateSampleData,
                modifier = Modifier.padding(innerPadding)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(innerPadding),
                contentPadding = PaddingValues(bottom = when {
                    !hasBanner -> 0.dp
                    isCatalogPublished -> 152.dp
                    else -> 88.dp
                }),
                state = scrollState,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                if (isLoading)
                    items(10) { ShimmerListItem(Modifier.fillMaxWidth()) }
                else {
                    items(if (text.isEmpty()) list else searchList) { product ->

                        ProductCardCompose(
                            product = product,
                            onLongClicked = { if (text.isEmpty()) onProductSelected(product.id) },
                            onCardClicked = { onCardClicked(product.id) })
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    if (orderedFilter)
        ModalBottomSheet(onDismissRequest = { orderedFilter = false }, sheetState = sheetState) {
            LazyColumn {
                items(orderList) { ordered ->
                    ListItem(
                        leadingContent = {
                            RadioButton(selected = ordered.isChecked, onClick = {
                                onCheckedChange(ordered)
                            })
                        },
                        headlineContent = {
                            Text(text = stringResource(ordered.text))
                        },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                    )
                }
            }
        }

    if (categoriesFilter)
        ModalBottomSheet(onDismissRequest = { categoriesFilter = false }, sheetState = sheetState) {
            LazyColumn {
                item {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp)
                    ) {
                        Text(text = stringResource(R.string.tittle_categories))
                        IconButton(onClick = {
                            categoriesFilter = false
                            onEditCategoriesClicked()
                        }) {
                            Icon(Icons.Default.Edit, null)
                        }
                    }
                }
                items(categories) { category ->
                    ListItem(
                        leadingContent = {
                            Checkbox(checked = category.isChecked, onCheckedChange = {
                                onCategoryChecked(category)
                            })
                        },
                        headlineContent = {
                            if (category.text.isEmpty())
                                Text(text = stringResource(R.string.txt_uncategorized))
                            else
                                Text(text = category.text)
                        },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                    )
                }
            }
        }
}


@Composable
fun EmptyProductsState(
    onAddProductClicked: () -> Unit,
    onGenerateSampleDataClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(R.drawable.baseline_insert_photo_24),
            contentDescription = null,
            modifier = Modifier.size(120.dp)
        )
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = stringResource(R.string.txt_empty_products_title),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = stringResource(R.string.txt_empty_products_desc),
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(32.dp))
        Button(
            onClick = onAddProductClicked,
            modifier = Modifier
                .widthIn(max = 400.dp)
                .fillMaxWidth(),
            shape = MaterialTheme.shapes.medium
        ) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.size(8.dp))
            Text(text = stringResource(R.string.btn_add_first_product))
        }
        Spacer(modifier = Modifier.height(12.dp))
        TextButton(
            onClick = onGenerateSampleDataClicked,
            modifier = Modifier
                .widthIn(max = 400.dp)
                .fillMaxWidth(),
        ) {
            Text(text = stringResource(R.string.btn_generate_sample_data))
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewEmptyProductsState() {
    PuntroSalesDemoTheme {
        EmptyProductsState(onAddProductClicked = { }, onGenerateSampleDataClicked = { })
    }
}


fun fakeProductsList(qty: Int): List<ProductUiModel> {
    val fakeList = mutableListOf<ProductUiModel>()
    for (i in 1L..qty) {
        fakeList.add(ProductUiModel(i, "Product Name $i", "3.00", "pz", stock = "1", null, null))
    }
    return fakeList
}

/**
 * List of products state impl
 * This composable function is in charge of handling the UI events
 * observing states from the viewModel and remembering Coroutine Scope
 * in oder to make more lifecycle aware
 * @param productsViewModel this ViewModel of type ProductsViewModel is used hold the data and update the list once it's retrieve from the repository
 * @param onNavigateAction this lambda function allows you to navigate to another UI according to the value sent.<br> Example: onNavigate(1) will launch the Details screen of the product with the id = 1
 *
 */
@SuppressLint("RememberReturnType")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListOfProductsStateImpl(
    productsViewModel: ProductsViewModel,
    onCategoriesNav: () -> Unit,
    onCreateCatalog: (List<Long>) -> Unit = {},
    onManagementAction: () -> Unit = {},
    banner: @Composable () -> Unit = {},
    onNavigateAction: (Long?) -> Unit,
) {
    val scope = rememberCoroutineScope()

    val productsList by productsViewModel.productsList.collectAsState()
    val uiState by productsViewModel.uiState.collectAsState()

    val filters by productsViewModel.filtersState.collectAsState()

    val categories by productsViewModel.categories.collectAsState()

    var showShareReport by remember { mutableStateOf(false) }

    val showOptions by remember {
        derivedStateOf {
            productsList.any { it.isSelected || uiState.enableSelection }
        }
    }
    ListOfProducts(
        banner = banner,
        list = productsList.toMutableStateList(),
        isLoading = uiState.isFetchingProducts,
        searchList = uiState.productsFiltered,
        onSearchProduct = { productsViewModel.onSearchAction(it) },
        orderList = filters,
        onCheckedChange = { productsViewModel.onFilterChange(it) },
        categories = categories,
        onCategoryChecked = { productsViewModel.onFilterCategory(it) },
        onEditCategoriesClicked = onCategoriesNav,
        onProductSelected = { productsViewModel.onProductSelected(it) },
        onCardClicked = {
            if (showOptions)
                productsViewModel.onProductSelected(it)
            else
                scope.launch { onNavigateAction(it) }
        },
        itemsSelectedQty = uiState.idsSelected.size,
        showDownloadOptions = showOptions,
        onHideDownloadOptions = { productsViewModel.onClearSelections() },
        onDownloadClicked = { productsViewModel.onProcessProducts() },
        onSelectAllChecked = { productsViewModel.onSelectAllProducts(it) }, // for selection all item
        allSelected = uiState.allSelected,
        onNavigateAction = { onNavigateAction(null) },
        onGenerateSampleData = { productsViewModel.generateSampleData() },
        isCatalogPublished = uiState.isCatalogPublished,
        onManagementAction = onManagementAction
    )

    UiStateHandler(uiState) {

    }

    LaunchedEffect(uiState) {
        if (uiState.catalogFile != null)
            showShareReport = true
    }

    val context = LocalContext.current
    if (showShareReport)
        ModalBottomSheet(onDismissRequest = {
            showShareReport = false
            productsViewModel.onCatalogShared()
        }
        ) {
            Column(
                Modifier.padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = {
                        uiState.catalogFile?.open(context)
                    }) {
                        Text(stringResource(R.string.btn_download_products_csv))
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    IconButton(onClick = {
                        uiState.catalogFile?.share(context)
                    }) { Icon(Icons.Default.Share, null) }
                    IconButton(onClick = {
                        uiState.catalogFile?.download(context)
                    }) { Icon(painterResource(R.drawable.download), null) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = {
                        showShareReport = false
                        onCreateCatalog(uiState.idsSelected)
                    }) {
                        Text(stringResource(R.string.txt_catalog_pdf))
                    }
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
}


@Preview(showBackground = true)
@Composable
private fun PreviewListOfProducts() {
    PuntroSalesDemoTheme {
        Surface(
            modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background
        ) {

            ListOfProducts(list = fakeProductsList(20), false) {
                Log.d(TAG, "PreviewListOfProducts: ")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun PreviewListOfProductsCatalogPublished() {
    PuntroSalesDemoTheme {
        Surface(
            modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background
        ) {
            ListOfProducts(
                list = fakeProductsList(20),
                isCatalogPublished = true,
                onManagementAction = { },
                onNavigateAction = { }
            )
        }
    }
}

enum class ListProductsTestTags(val tag: String) {
    CARD("ElevatedCard")
}