package com.imecatro.products.ui.details.model

import com.imecatro.demosales.ui.theme.architect.ErrorUiModel
import com.imecatro.demosales.ui.theme.architect.Idle
import com.imecatro.demosales.ui.theme.architect.UiState
import java.io.File

data class ProductDetailsUiModel(
    val id: Long?,
    val name: String?,
    val price: String?,
    val unit: String?,
    val currency: String?,
    val imageUrl: String?,
    val details: String?,
    val barcode: String,
    val stockQty: String,
    val stockPrice: String,
    val stockHistory: List<History>,
    val isProcessingCsv : Boolean = false,
    val file : File? = null,
    val categoryName: String,
    val productDeleted : Boolean = false,
) : UiState {

    /**
     * @param date is when the movement has been made
     */
    data class History(
        val date: String,
        val qty: String,
        val tittle: String
    )

    override fun isFetchingOrProcessingData(): Boolean {
        return isProcessingCsv
    }

    override fun getError(): ErrorUiModel? {
        return null
    }

    companion object : Idle<ProductDetailsUiModel> {
        override val idle: ProductDetailsUiModel
            get() = ProductDetailsUiModel(
                0,
                "Product",
                "0.00",
                "",
                "",
                null,
                "",
                barcode = "",
                stockQty = "0.0",
                stockPrice = "0",
                stockHistory = emptyList(),
                categoryName = ""
            )
    }
}
