pluginManagement {
    repositories {
        gradlePluginPortal()
        google()
        mavenCentral()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "PuntroSales-Demo"
include(":app")
include(":demosales-data:products")
include(":demosales-ui:products")
include(":demosales-domain:sales")
include(":demosales-domain:products")
include(":demosales-ui:sales")
include(":demosales-ui:theme")
include(":demosales-data:sales")
include(":demosales-domain:core")
include(":demosales-domain:clients")
include(":demosales-ui:clients")
include(":demosales-data:clients")
