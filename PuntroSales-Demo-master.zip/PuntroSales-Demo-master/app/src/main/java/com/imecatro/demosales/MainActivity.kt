package com.imecatro.demosales

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.imecatro.demosales.ui.AppAdaptiveNavigation
import com.imecatro.demosales.ui.theme.PuntroSalesDemoTheme
import com.imecatro.demosales.ui.viewmodels.MainViewModel
import dagger.hilt.android.AndroidEntryPoint
import com.imecatro.demosales.onboarding.OnboardingComponent
import javax.inject.Inject

/**
 * Main entry point for the application.
 *
 * This activity is annotated with [AndroidEntryPoint] to enable Hilt dependency injection.
 * It serves as the host for the Compose UI and manages the initial configuration,
 * including edge-to-edge display and the root navigation structure.
 *
 * Applies the [PuntroSalesDemoTheme] and sets up a [Surface] with the theme's background color.
 */
@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    @Inject lateinit var onboardingComponent: OnboardingComponent

    private val mainViewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            val uiState by mainViewModel.uiState.collectAsStateWithLifecycle()
            val darkTheme = uiState.isDarkTheme ?: isSystemInDarkTheme()

            // Apply global language preference
            LaunchedEffect(uiState.language) {
                uiState.language?.let { lang ->
                    val appLocales = AppCompatDelegate.getApplicationLocales()
                    val currentLang = if (!appLocales.isEmpty) appLocales.get(0)?.language else null
                    
                    if (lang != currentLang) {
                        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(lang))
                    }
                }
            }

            PuntroSalesDemoTheme(
                darkTheme = darkTheme,
                currencyCode = uiState.currency ?: "USD"
            ) {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppAdaptiveNavigation(onboardingComponent)
                }
            }
        }
    }
}