package com.imecatro.demosales.profile.ui.uistate

import com.imecatro.demosales.domain.core.profile.model.UserProfileDomainModel
import com.imecatro.demosales.profile.ui.mappers.toUiModel
import com.imecatro.demosales.profile.ui.model.UserProfileUiModel
import com.imecatro.demosales.ui.theme.architect.ErrorUiModel
import com.imecatro.demosales.ui.theme.architect.Idle
import com.imecatro.demosales.ui.theme.architect.UiState

data class ProfileUiState(
    val profile: UserProfileUiModel,
    val isLoading: Boolean = false,
    val profileError: String? = null,
    val isUserAuthenticated: Boolean = false,
    val cloudAccountName: String? = null
) : UiState {
    override fun isFetchingOrProcessingData(): Boolean = isLoading

    override fun getError(): ErrorUiModel? = profileError?.let { ErrorUiModel(message = it) }

    companion object : Idle<ProfileUiState> {
        override val idle: ProfileUiState
            get() = ProfileUiState(
                profile = UserProfileDomainModel.default.toUiModel()
            )
    }
}
