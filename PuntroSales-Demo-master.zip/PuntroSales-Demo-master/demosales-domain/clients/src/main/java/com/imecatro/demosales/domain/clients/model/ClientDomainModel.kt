package com.imecatro.demosales.domain.clients.model

/**
 * Data class representing a client in the domain layer.
 *
 * @param id Unique identifier for the client.
 * @param name The client's full name.
 * @param phoneNumber The client's phone number.
 * @param shipping The client's shipping address.
 * @param avatarUri The URL of the client's avatar image.
 * @param latitude The client's location latitude.
 * @param longitude The client's location longitude.
 * @param accumulatedPurchases The sum of all totals' in purchases made by the client
 * @param isFavorite If the user selected as favorite
 */
data class ClientDomainModel(
    val id: Long = 0,
    val name: String,
    val phoneNumber: String,
    val shipping: String,
    val avatarUri: String?,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val accumulatedPurchases: Double = 0.0,
    val isFavorite : Boolean = false,
)