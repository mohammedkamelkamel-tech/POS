package com.alkamel.lahmpos;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    Db db;
    LinearLayout root, header, content, nav;
    int page = 0;
    final int BG = 0xFF09241F, PANEL = 0xFF12332D, BORDER = 0xFF244A42, TEAL = 0xFF45A997, WHITE = 0xFFF1F7F4, MUTED = 0xFFA6BDB5, GOLD = 0xFFE1B85A;
    EditText weightInput, priceInput;
    TextView totalValue;
    ArrayList<CartItem> cart = new ArrayList<>();
    DecimalFormat money = new DecimalFormat("#,##0.##");

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        db = new Db(this); seed();
        showPage(0);
    }
    void seed() {
        if (db.countProducts()==0) {
            db.addProduct("لحم غنم", 6500); db.addProduct("لحم بقري", 4800);
            db.addProduct("كبدة", 7000); db.addProduct("مفروم", 6000); db.addProduct("شحم", 2500);
        }
    }
    int dp(float x){ return (int)(x*getResources().getDisplayMetrics().density+.5f); }
    TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); t.setTypeface(null,bold?Typeface.BOLD:Typeface.NORMAL);
        t.setPadding(dp(8),dp(6),dp(8),dp(6)); return t;
    }
    GradientDrawable bg(int color,int stroke){
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(16)); d.setStroke(dp(1),stroke); return d;
    }
    LinearLayout vertical(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    LinearLayout horizontal(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    Button button(String label,Runnable action){
        Button b=new Button(this); b.setText(label); b.setTextColor(BG); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(TEAL));
        b.setOnClickListener(v->action.run()); return b;
    }
    EditText edit(String hint, boolean decimal){
        EditText e=new EditText(this); e.setSingleLine(true); e.setTextColor(WHITE); e.setHintTextColor(MUTED); e.setHint(hint);
        e.setTextSize(16); e.setPadding(dp(12),dp(8),dp(12),dp(8)); e.setBackground(bg(PANEL,BORDER));
        e.setInputType(decimal?8194:2); e.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); return e;
    }
    void showPage(int p){
        page=p;
        root=vertical(); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); root.setBackgroundColor(BG);
        header=vertical(); header.setPadding(dp(16),dp(14),dp(16),dp(8));
        TextView title=text("الكامل للحوم",24,WHITE,true); header.addView(title);
        header.addView(text(p==0?"بيع وفاتورة سريعة":p==1?"الأصناف والمخزون":p==2?"التقارير اليومية":"الإعدادات",14,MUTED,false));
        root.addView(header);
        ScrollView sc=new ScrollView(this); content=vertical(); content.setPadding(dp(14),dp(8),dp(14),dp(16)); sc.addView(content);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        nav=horizontal(); nav.setPadding(dp(8),dp(6),dp(8),dp(6)); nav.setBackgroundColor(PANEL);
        String[] names={"البيع","الأصناف","التقارير","الإعدادات"};
        for(int i=0;i<names.length;i++){ final int n=i; TextView t=text((i==p?"● ":"")+names[i],14,i==p?TEAL:MUTED,true); t.setGravity(Gravity.CENTER); nav.addView(t,new LinearLayout.LayoutParams(0,dp(54),1)); t.setOnClickListener(v->showPage(n)); }
        root.addView(nav); setContentView(root);
        if(p==0) salesPage(); else if(p==1) productsPage(); else if(p==2) reportsPage(); else settingsPage();
    }
    void section(String title){
        TextView t=text(title,18,WHITE,true); t.setPadding(dp(4),dp(14),dp(4),dp(8)); content.addView(t);
    }
    void card(View v){ LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(10); v.setBackground(bg(PANEL,BORDER)); v.setPadding(dp(12),dp(10),dp(12),dp(10)); content.addView(v,lp); }
    void salesPage(){
        section("فاتورة بيع جديدة");
        LinearLayout form=vertical();
        TextView note=text("اختر نوع اللحم، أدخل الوزن بالكيلو والسعر لكل كيلو.",14,MUTED,false); form.addView(note);
        Spinner spinner=new Spinner(this); ArrayList<String> products=db.productNames(); ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,products); spinner.setAdapter(adapter); form.addView(spinner);
        weightInput=edit("الوزن بالكيلو (مثال 1.25)",true); LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(52)); ep.topMargin=dp(8); form.addView(weightInput,ep);
        priceInput=edit("سعر الكيلو بالريال",true); ep=new LinearLayout.LayoutParams(-1,dp(52)); ep.topMargin=dp(8); form.addView(priceInput,ep);
        totalValue=text("الإجمالي: 0 ريال",20,GOLD,true); totalValue.setGravity(Gravity.CENTER);
        ep=new LinearLayout.LayoutParams(-1,dp(54)); ep.topMargin=dp(8); form.addView(totalValue,ep);
        Button add=button("إضافة للفاتورة",()->{
            try{
                String name=(String)spinner.getSelectedItem();
                double w=Double.parseDouble(weightInput.getText().toString().trim());
                double price=Double.parseDouble(priceInput.getText().toString().trim());
                if(w<=0||price<0) throw new Exception("أدخل وزنًا أكبر من صفر وسعرًا صحيحًا");
                cart.add(new CartItem(name,w,price)); weightInput.setText(""); updateCart();
                ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(weightInput.getWindowToken(),0);
            }catch(Exception ex){ toast("أدخل الوزن والسعر بشكل صحيح"); }
        });
        ep=new LinearLayout.LayoutParams(-1,dp(50)); ep.topMargin=dp(8); form.addView(add,ep); card(form);
        section("محتويات الفاتورة");
        updateCart();
    }
    void updateCart(){
        if(page!=0) return;
        // remove previously drawn cart views after the form and section title
        while(content.getChildCount()>2) content.removeViewAt(2);
        double sum=0;
        if(cart.isEmpty()){ TextView empty=text("الفاتورة فارغة. أضف الأصناف أعلاه.",15,MUTED,false); card(empty); }
        for(int i=0;i<cart.size();i++){
            final int idx=i; CartItem c=cart.get(i); sum+=c.weight*c.price;
            LinearLayout row=horizontal(); row.addView(text(c.name+"  •  "+c.weight+" كجم × "+money.format(c.price)+" = "+money.format(c.weight*c.price)+" ريال",14,WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
            TextView del=text("حذف",13,0xFFFF8A80,true); row.addView(del); del.setOnClickListener(v->{cart.remove(idx); updateCart();});
            card(row);
        }
        LinearLayout bottom=vertical(); TextView sumText=text("الإجمالي المستحق: "+money.format(sum)+" ريال",20,GOLD,true); sumText.setGravity(Gravity.CENTER); bottom.addView(sumText);
        EditText customer=edit("اسم العميل (اختياري)",false); bottom.addView(customer);
        Button save=button("حفظ الفاتورة نقدًا",()->{
            if(cart.isEmpty()){toast("أضف صنفًا للفاتورة أولًا");return;}
            String customerName=customer.getText().toString().trim();
            db.saveSale(customerName,cart,sum);
            cart.clear(); toast("تم حفظ الفاتورة محليًا"); showPage(0);
        });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(50)); lp.topMargin=dp(8); bottom.addView(save,lp); card(bottom);
    }
    void productsPage(){
        section("الأصناف");
        EditText name=edit("اسم الصنف (لحم غنم، بقري، كبدة...)",false); content.addView(name);
        EditText price=edit("سعر الكيلو بالريال",true); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52)); lp.topMargin=dp(8); content.addView(price,lp);
        Button add=button("حفظ الصنف",()->{
            String n=name.getText().toString().trim(); try{double pr=Double.parseDouble(price.getText().toString().trim()); if(n.isEmpty()||pr<0)throw new Exception(); db.addProduct(n,pr); toast("تم حفظ الصنف"); showPage(1);}catch(Exception e){toast("أدخل اسم الصنف والسعر بشكل صحيح");}
        }); lp=new LinearLayout.LayoutParams(-1,dp(50)); lp.topMargin=dp(8); content.addView(add,lp);
        section("قائمة الأصناف والأسعار");
        Cursor c=db.getProducts();
        while(c.moveToNext()){
            String n=c.getString(1); double pr=c.getDouble(2);
            LinearLayout row=horizontal(); row.addView(text(n,16,WHITE,true),new LinearLayout.LayoutParams(0,-2,1)); row.addView(text(money.format(pr)+" ر.ي/كجم",14,GOLD,true));
            card(row);
        } c.close();
    }
    void reportsPage(){
        section("ملخص المبيعات");
        Cursor c=db.getSummary();
        double total=0; int count=0;
        if(c.moveToFirst()){ total=c.getDouble(0); count=c.getInt(1); } c.close();
        TextView amount=text("مبيعات اليوم\n"+money.format(total)+" ريال",22,GOLD,true); amount.setGravity(Gravity.CENTER); card(amount);
        TextView invoices=text("عدد الفواتير: "+count,17,WHITE,true); card(invoices);
        section("آخر الفواتير");
        Cursor s=db.getRecentSales();
        while(s.moveToNext()){
            TextView row=text("#"+s.getInt(0)+"  "+s.getString(1)+"  •  "+money.format(s.getDouble(2))+" ريال",14,WHITE,false); card(row);
        } s.close();
    }
    void settingsPage(){
        section("إعدادات المحل");
        TextView about=text("الكامل للحوم\nنظام بيع ومخزون يعمل دون إنترنت ويحفظ البيانات على هذا الهاتف.",16,WHITE,false); card(about);
        Button export=button("تصدير نسخة احتياطية CSV",()->{
            try{
                StringBuilder csv=new StringBuilder("id,name,price_per_kg\\n"); Cursor c=db.getProducts();
                while(c.moveToNext()) csv.append(c.getInt(0)).append(",\\\"").append(c.getString(1).replace("\\\"","\\\"\\\"")).append("\\\",").append(c.getDouble(2)).append("\\n");
                java.io.File f=new java.io.File(getExternalFilesDir(null),"lahmpos-products.csv");
                java.io.FileOutputStream out=new java.io.FileOutputStream(f); out.write(csv.toString().getBytes("UTF-8")); out.close();
                Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/csv"); i.putExtra(Intent.EXTRA_STREAM,android.net.Uri.fromFile(f)); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(Intent.createChooser(i,"مشاركة النسخة الاحتياطية"));
            }catch(Exception e){toast("تعذر إنشاء النسخة الاحتياطية");}
        }); card(export);
    }
    void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }

    static class CartItem { String name; double weight,price; CartItem(String n,double w,double p){name=n;weight=w;price=p;} }
    static class Db extends SQLiteOpenHelper {
        Db(Context c){super(c,"lahmpos.db",null,1);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,price REAL NOT NULL)");
            d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,customer TEXT,date TEXT,total REAL)");
            d.execSQL("CREATE TABLE sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT,sale_id INTEGER,name TEXT,weight REAL,price REAL,total REAL)");
        }
        public void onUpgrade(SQLiteDatabase d,int old,int now){}
        void addProduct(String n,double p){ SQLiteDatabase d=getWritableDatabase(); ContentValues v=new ContentValues();v.put("name",n);v.put("price",p);d.insert("products",null,v);}
        int countProducts(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM products",null);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        ArrayList<String> productNames(){ArrayList<String>a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT name FROM products ORDER BY id",null);while(c.moveToNext())a.add(c.getString(0));c.close();if(a.isEmpty())a.add("لحم غنم");return a;}
        Cursor getProducts(){return getReadableDatabase().rawQuery("SELECT id,name,price FROM products ORDER BY name",null);}
        void saveSale(String customer,ArrayList<CartItem> items,double sum){
            SQLiteDatabase d=getWritableDatabase();d.beginTransaction();
            try{
                ContentValues v=new ContentValues();v.put("customer",customer);v.put("date",new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()));v.put("total",sum);
                long id=d.insert("sales",null,v);
                for(CartItem x:items){ContentValues it=new ContentValues();it.put("sale_id",id);it.put("name",x.name);it.put("weight",x.weight);it.put("price",x.price);it.put("total",x.weight*x.price);d.insert("sale_items",null,it);}
                d.setTransactionSuccessful();
            }finally{d.endTransaction();}
        }
        Cursor getSummary(){return getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0),COUNT(*) FROM sales WHERE date=?",new String[]{new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date())});}
        Cursor getRecentSales(){return getReadableDatabase().rawQuery("SELECT id,customer,total FROM sales ORDER BY id DESC LIMIT 20",null);}
    }
}
