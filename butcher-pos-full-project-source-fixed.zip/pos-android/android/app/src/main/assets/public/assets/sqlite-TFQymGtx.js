const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Dhd-LRYt.js","assets/dist-1nWD4rOe.js","assets/loader-BBfSJ8Qr.js","assets/preload-helper-Czpn1I53.js"])))=>i.map(i=>d[i]);
import{a as e,t}from"./dist-1nWD4rOe.js";import{t as n}from"./preload-helper-Czpn1I53.js";var r=class{constructor(e){this.sqlite=e,this._connectionDict=new Map}async initWebStore(){try{return await this.sqlite.initWebStore(),Promise.resolve()}catch(e){return Promise.reject(e)}}async saveToStore(e){try{return await this.sqlite.saveToStore({database:e}),Promise.resolve()}catch(e){return Promise.reject(e)}}async saveToLocalDisk(e){try{return await this.sqlite.saveToLocalDisk({database:e}),Promise.resolve()}catch(e){return Promise.reject(e)}}async getFromLocalDiskToStore(e){let t=e??!0;try{return await this.sqlite.getFromLocalDiskToStore({overwrite:t}),Promise.resolve()}catch(e){return Promise.reject(e)}}async echo(e){try{let t=await this.sqlite.echo({value:e});return Promise.resolve(t)}catch(e){return Promise.reject(e)}}async isSecretStored(){try{let e=await this.sqlite.isSecretStored();return Promise.resolve(e)}catch(e){return Promise.reject(e)}}async setEncryptionSecret(e){try{return await this.sqlite.setEncryptionSecret({passphrase:e}),Promise.resolve()}catch(e){return Promise.reject(e)}}async changeEncryptionSecret(e,t){try{return await this.sqlite.changeEncryptionSecret({passphrase:e,oldpassphrase:t}),Promise.resolve()}catch(e){return Promise.reject(e)}}async clearEncryptionSecret(){try{return await this.sqlite.clearEncryptionSecret(),Promise.resolve()}catch(e){return Promise.reject(e)}}async checkEncryptionSecret(e){try{let t=await this.sqlite.checkEncryptionSecret({passphrase:e});return Promise.resolve(t)}catch(e){return Promise.reject(e)}}async addUpgradeStatement(e,t){try{return e.endsWith(`.db`)&&(e=e.slice(0,-3)),await this.sqlite.addUpgradeStatement({database:e,upgrade:t}),Promise.resolve()}catch(e){return Promise.reject(e)}}async createConnection(e,t,n,r,a){try{e.endsWith(`.db`)&&(e=e.slice(0,-3)),await this.sqlite.createConnection({database:e,encrypted:t,mode:n,version:r,readonly:a});let o=new i(e,a,this.sqlite),s=a?`RO_${e}`:`RW_${e}`;return this._connectionDict.set(s,o),Promise.resolve(o)}catch(e){return Promise.reject(e)}}async closeConnection(e,t){try{e.endsWith(`.db`)&&(e=e.slice(0,-3)),await this.sqlite.closeConnection({database:e,readonly:t});let n=t?`RO_${e}`:`RW_${e}`;return this._connectionDict.delete(n),Promise.resolve()}catch(e){return Promise.reject(e)}}async isConnection(e,t){let n={};e.endsWith(`.db`)&&(e=e.slice(0,-3));let r=t?`RO_${e}`:`RW_${e}`;return n.result=this._connectionDict.has(r),Promise.resolve(n)}async retrieveConnection(e,t){e.endsWith(`.db`)&&(e=e.slice(0,-3));let n=t?`RO_${e}`:`RW_${e}`;if(this._connectionDict.has(n)){let t=this._connectionDict.get(n);return t===void 0?Promise.reject(`Connection ${e} is undefined`):Promise.resolve(t)}return Promise.reject(`Connection ${e} does not exist`)}async getNCDatabasePath(e,t){try{let n=await this.sqlite.getNCDatabasePath({path:e,database:t});return Promise.resolve(n)}catch(e){return Promise.reject(e)}}async createNCConnection(e,t){try{await this.sqlite.createNCConnection({databasePath:e,version:t});let n=new i(e,!0,this.sqlite),r=`RO_${e})`;return this._connectionDict.set(r,n),Promise.resolve(n)}catch(e){return Promise.reject(e)}}async closeNCConnection(e){try{await this.sqlite.closeNCConnection({databasePath:e});let t=`RO_${e})`;return this._connectionDict.delete(t),Promise.resolve()}catch(e){return Promise.reject(e)}}async isNCConnection(e){let t={},n=`RO_${e})`;return t.result=this._connectionDict.has(n),Promise.resolve(t)}async retrieveNCConnection(e){if(this._connectionDict.has(e)){let t=`RO_${e})`,n=this._connectionDict.get(t);return n===void 0?Promise.reject(`Connection ${e} is undefined`):Promise.resolve(n)}return Promise.reject(`Connection ${e} does not exist`)}async isNCDatabase(e){try{let t=await this.sqlite.isNCDatabase({databasePath:e});return Promise.resolve(t)}catch(e){return Promise.reject(e)}}async retrieveAllConnections(){return this._connectionDict}async closeAllConnections(){let e=new Map;try{for(let t of this._connectionDict.keys()){let n=t.substring(3),r=t.substring(0,3)===`RO_`;await this.sqlite.closeConnection({database:n,readonly:r}),e.set(t,null)}for(let t of e.keys())this._connectionDict.delete(t);return Promise.resolve()}catch(e){return Promise.reject(e)}}async checkConnectionsConsistency(){try{let e=[...this._connectionDict.keys()],t=[],n=[];for(let r of e)t.push(r.substring(0,2)),n.push(r.substring(3));let r=await this.sqlite.checkConnectionsConsistency({dbNames:n,openModes:t});return r.result||(this._connectionDict=new Map),Promise.resolve(r)}catch(e){return this._connectionDict=new Map,Promise.reject(e)}}async importFromJson(e){try{let t=await this.sqlite.importFromJson({jsonstring:e});return Promise.resolve(t)}catch(e){return Promise.reject(e)}}async isJsonValid(e){try{let t=await this.sqlite.isJsonValid({jsonstring:e});return Promise.resolve(t)}catch(e){return Promise.reject(e)}}async copyFromAssets(e){let t=e??!0;try{return await this.sqlite.copyFromAssets({overwrite:t}),Promise.resolve()}catch(e){return Promise.reject(e)}}async getFromHTTPRequest(e,t){let n=t??!0;try{return await this.sqlite.getFromHTTPRequest({url:e,overwrite:n}),Promise.resolve()}catch(e){return Promise.reject(e)}}async isDatabaseEncrypted(e){e.endsWith(`.db`)&&(e=e.slice(0,-3));try{let t=await this.sqlite.isDatabaseEncrypted({database:e});return Promise.resolve(t)}catch(e){return Promise.reject(e)}}async isInConfigEncryption(){try{let e=await this.sqlite.isInConfigEncryption();return Promise.resolve(e)}catch(e){return Promise.reject(e)}}async isInConfigBiometricAuth(){try{let e=await this.sqlite.isInConfigBiometricAuth();return Promise.resolve(e)}catch(e){return Promise.reject(e)}}async isDatabase(e){e.endsWith(`.db`)&&(e=e.slice(0,-3));try{let t=await this.sqlite.isDatabase({database:e});return Promise.resolve(t)}catch(e){return Promise.reject(e)}}async getDatabaseList(){try{let e=(await this.sqlite.getDatabaseList()).values;e.sort();let t={values:e};return Promise.resolve(t)}catch(e){return Promise.reject(e)}}async getMigratableDbList(e){let t=e||`default`;try{let e=await this.sqlite.getMigratableDbList({folderPath:t});return Promise.resolve(e)}catch(e){return Promise.reject(e)}}async addSQLiteSuffix(e,t){let n=e||`default`,r=t||[];try{let e=await this.sqlite.addSQLiteSuffix({folderPath:n,dbNameList:r});return Promise.resolve(e)}catch(e){return Promise.reject(e)}}async deleteOldDatabases(e,t){let n=e||`default`,r=t||[];try{let e=await this.sqlite.deleteOldDatabases({folderPath:n,dbNameList:r});return Promise.resolve(e)}catch(e){return Promise.reject(e)}}async moveDatabasesAndAddSuffix(e,t){let n=e||`default`,r=t||[];return this.sqlite.moveDatabasesAndAddSuffix({folderPath:n,dbNameList:r})}},i=class{constructor(e,t,n){this.dbName=e,this.readonly=t,this.sqlite=n}getConnectionDBName(){return this.dbName}getConnectionReadOnly(){return this.readonly}async open(){try{return await this.sqlite.open({database:this.dbName,readonly:this.readonly}),Promise.resolve()}catch(e){return Promise.reject(e)}}async close(){try{return await this.sqlite.close({database:this.dbName,readonly:this.readonly}),Promise.resolve()}catch(e){return Promise.reject(e)}}async beginTransaction(){try{let e=await this.sqlite.beginTransaction({database:this.dbName});return Promise.resolve(e)}catch(e){return Promise.reject(e)}}async commitTransaction(){try{let e=await this.sqlite.commitTransaction({database:this.dbName});return Promise.resolve(e)}catch(e){return Promise.reject(e)}}async rollbackTransaction(){try{let e=await this.sqlite.rollbackTransaction({database:this.dbName});return Promise.resolve(e)}catch(e){return Promise.reject(e)}}async isTransactionActive(){try{let e=await this.sqlite.isTransactionActive({database:this.dbName});return Promise.resolve(e)}catch(e){return Promise.reject(e)}}async loadExtension(e){try{return await this.sqlite.loadExtension({database:this.dbName,path:e,readonly:this.readonly}),Promise.resolve()}catch(e){return Promise.reject(e)}}async enableLoadExtension(e){try{return await this.sqlite.enableLoadExtension({database:this.dbName,toggle:e,readonly:this.readonly}),Promise.resolve()}catch(e){return Promise.reject(e)}}async getUrl(){try{let e=await this.sqlite.getUrl({database:this.dbName,readonly:this.readonly});return Promise.resolve(e)}catch(e){return Promise.reject(e)}}async getVersion(){try{let e=await this.sqlite.getVersion({database:this.dbName,readonly:this.readonly});return Promise.resolve(e)}catch(e){return Promise.reject(e)}}async getTableList(){try{let e=await this.sqlite.getTableList({database:this.dbName,readonly:this.readonly});return Promise.resolve(e)}catch(e){return Promise.reject(e)}}async execute(e,t=!0,n=!0){try{if(this.readonly)return Promise.reject(`not allowed in read-only mode`);{let r=await this.sqlite.execute({database:this.dbName,statements:e,transaction:t,readonly:!1,isSQL92:n});return Promise.resolve(r)}}catch(e){return Promise.reject(e)}}async query(e,t,n=!0){let r;try{return r=t&&t.length>0?await this.sqlite.query({database:this.dbName,statement:e,values:t,readonly:this.readonly,isSQL92:!0}):await this.sqlite.query({database:this.dbName,statement:e,values:[],readonly:this.readonly,isSQL92:n}),r=await this.reorderRows(r),Promise.resolve(r)}catch(e){return Promise.reject(e)}}async run(e,t,n=!0,r=`no`,i=!0){let a;try{return this.readonly?Promise.reject(`not allowed in read-only mode`):(a=t&&t.length>0?await this.sqlite.run({database:this.dbName,statement:e,values:t,transaction:n,readonly:!1,returnMode:r,isSQL92:!0}):await this.sqlite.run({database:this.dbName,statement:e,values:[],transaction:n,readonly:!1,returnMode:r,isSQL92:i}),a.changes=await this.reorderRows(a.changes),Promise.resolve(a))}catch(e){return Promise.reject(e)}}async executeSet(e,t=!0,n=`no`,r=!0){let i;try{return this.readonly?Promise.reject(`not allowed in read-only mode`):(i=await this.sqlite.executeSet({database:this.dbName,set:e,transaction:t,readonly:!1,returnMode:n,isSQL92:r}),i.changes=await this.reorderRows(i.changes),Promise.resolve(i))}catch(e){return Promise.reject(e)}}async isExists(){try{let e=await this.sqlite.isDBExists({database:this.dbName,readonly:this.readonly});return Promise.resolve(e)}catch(e){return Promise.reject(e)}}async isTable(e){try{let t=await this.sqlite.isTableExists({database:this.dbName,table:e,readonly:this.readonly});return Promise.resolve(t)}catch(e){return Promise.reject(e)}}async isDBOpen(){try{let e=await this.sqlite.isDBOpen({database:this.dbName,readonly:this.readonly});return Promise.resolve(e)}catch(e){return Promise.reject(e)}}async delete(){try{return this.readonly?Promise.reject(`not allowed in read-only mode`):(await this.sqlite.deleteDatabase({database:this.dbName,readonly:!1}),Promise.resolve())}catch(e){return Promise.reject(e)}}async createSyncTable(){try{if(this.readonly)return Promise.reject(`not allowed in read-only mode`);{let e=await this.sqlite.createSyncTable({database:this.dbName,readonly:!1});return Promise.resolve(e)}}catch(e){return Promise.reject(e)}}async setSyncDate(e){try{return this.readonly?Promise.reject(`not allowed in read-only mode`):(await this.sqlite.setSyncDate({database:this.dbName,syncdate:e,readonly:!1}),Promise.resolve())}catch(e){return Promise.reject(e)}}async getSyncDate(){try{let e=await this.sqlite.getSyncDate({database:this.dbName,readonly:this.readonly}),t=``;return e.syncDate>0&&(t=new Date(e.syncDate*1e3).toISOString()),Promise.resolve(t)}catch(e){return Promise.reject(e)}}async exportToJson(e,t=!1){try{let n=await this.sqlite.exportToJson({database:this.dbName,jsonexportmode:e,readonly:this.readonly,encrypted:t});return Promise.resolve(n)}catch(e){return Promise.reject(e)}}async deleteExportedRows(){try{return this.readonly?Promise.reject(`not allowed in read-only mode`):(await this.sqlite.deleteExportedRows({database:this.dbName,readonly:!1}),Promise.resolve())}catch(e){return Promise.reject(e)}}async executeTransaction(e,t=!0){let n=0,r=!1;if(this.readonly)return Promise.reject(`not allowed in read-only mode`);if(await this.sqlite.beginTransaction({database:this.dbName}),r=await this.sqlite.isTransactionActive({database:this.dbName}),!r)return Promise.reject(`After Begin Transaction, no transaction active`);try{for(let r of e){if(typeof r!=`object`||!(`statement`in r))throw Error(`Error a task.statement must be provided`);if(`values`in r&&r.values&&r.values.length>0){let e=r.statement.toUpperCase().includes(`RETURNING`)?`all`:`no`,i=await this.sqlite.run({database:this.dbName,statement:r.statement,values:r.values,transaction:!1,readonly:!1,returnMode:e,isSQL92:t});if(i.changes.changes<0)throw Error(`Error in transaction method run `);n+=i.changes.changes}else{let e=await this.sqlite.execute({database:this.dbName,statements:r.statement,transaction:!1,readonly:!1});if(e.changes.changes<0)throw Error(`Error in transaction method execute `);n+=e.changes.changes}}let r=await this.sqlite.commitTransaction({database:this.dbName});n+=r.changes.changes;let i={changes:{changes:n}};return Promise.resolve(i)}catch(e){let t=e.message?e.message:e;return await this.sqlite.rollbackTransaction({database:this.dbName}),Promise.reject(t)}}async reorderRows(e){let t=e;if(e?.values&&typeof e.values[0]==`object`&&Object.keys(e.values[0]).includes(`ios_columns`)){let n=e.values[0].ios_columns,r=[];for(let t=1;t<e.values.length;t++){let i=e.values[t],a={};for(let e of n)a[e]=i[e];r.push(a)}t.values=r}return Promise.resolve(t)}},a=e(`CapacitorSQLite`,{web:()=>n(()=>import(`./web-Dhd-LRYt.js`).then(e=>new e.CapacitorSQLiteWeb),__vite__mapDeps([0,1])),electron:()=>window.CapacitorCustomPlatform.plugins.CapacitorSQLite});function o(){return Date.now()}var s=new Intl.DateTimeFormat(`ar-YE`,{day:`2-digit`,month:`short`,year:`numeric`}),c=new Intl.DateTimeFormat(`ar-YE`,{day:`2-digit`,month:`short`,year:`numeric`,hour:`2-digit`,minute:`2-digit`}),l=new Intl.DateTimeFormat(`ar-YE`,{hour:`2-digit`,minute:`2-digit`});function u(e){return s.format(new Date(e))}function d(e){return c.format(new Date(e))}function f(e){return l.format(new Date(e))}function p(e){let t=new Date(e);return t.setHours(0,0,0,0),t.getTime()}function m(e){let t=new Date(e);return t.setHours(23,59,59,999),t.getTime()}function h(e){let t=new Date(e);return`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,`0`)}-${String(t.getDate()).padStart(2,`0`)}`}new Intl.DateTimeFormat(`ar-YE`,{month:`long`,year:`numeric`});var g=[];for(let e=0;e<256;++e)g.push((e+256).toString(16).slice(1));function _(e,t=0){return(g[e[t+0]]+g[e[t+1]]+g[e[t+2]]+g[e[t+3]]+`-`+g[e[t+4]]+g[e[t+5]]+`-`+g[e[t+6]]+g[e[t+7]]+`-`+g[e[t+8]]+g[e[t+9]]+`-`+g[e[t+10]]+g[e[t+11]]+g[e[t+12]]+g[e[t+13]]+g[e[t+14]]+g[e[t+15]]).toLowerCase()}var v=new Uint8Array(16);function y(){return crypto.getRandomValues(v)}function b(e,t,n){return!t&&!e&&crypto.randomUUID?crypto.randomUUID():x(e,t,n)}function x(e,t,n){e||={};let r=e.random??e.rng?.()??y();if(r.length<16)throw Error(`Random bytes length must be >= 16`);if(r[6]=r[6]&15|64,r[8]=r[8]&63|128,t){if(n||=0,n<0||n+16>t.length)throw RangeError(`UUID byte range ${n}:${n+15} is out of buffer bounds`);for(let e=0;e<16;++e)t[n+e]=r[e];return t}return _(r)}var S={};function C(e,t,n){let r;if(e)r=T(e.random??e.rng?.()??y(),e.msecs,e.seq,t,n);else{let e=Date.now(),i=y();w(S,e,i),r=T(i,S.msecs,S.seq,t,n)}return t??_(r)}function w(e,t,n){return e.msecs??=-1/0,e.seq??=0,t>e.msecs?(e.seq=n[6]<<23|n[7]<<16|n[8]<<8|n[9],e.msecs=t):(e.seq=e.seq+1|0,e.seq===0&&e.msecs++),e}function T(e,t,n,r,i=0){if(e.length<16)throw Error(`Random bytes length must be >= 16`);if(!r)r=new Uint8Array(16),i=0;else if(i<0||i+16>r.length)throw RangeError(`UUID byte range ${i}:${i+15} is out of buffer bounds`);return t??=Date.now(),n??=e[6]*127<<24|e[7]<<16|e[8]<<8|e[9],r[i++]=t/1099511627776&255,r[i++]=t/4294967296&255,r[i++]=t/16777216&255,r[i++]=t/65536&255,r[i++]=t/256&255,r[i++]=t&255,r[i++]=112|n>>>28&15,r[i++]=n>>>20&255,r[i++]=128|n>>>14&63,r[i++]=n>>>6&255,r[i++]=n<<2&255|e[10]&3,r[i++]=e[11],r[i++]=e[12],r[i++]=e[13],r[i++]=e[14],r[i++]=e[15],r}function E(){return b()}function D(){return C()}function O(e,t=4){return(e||b()).replace(/-/g,``).slice(-t).toUpperCase()}var k=[{name:`Penjualan`,type:`income`,isSystem:1},{name:`Modal / Setoran`,type:`income`,isSystem:0},{name:`Pendapatan Lain`,type:`income`,isSystem:0},{name:`Belanja Stok`,type:`expense`,isSystem:0},{name:`Gaji Karyawan`,type:`expense`,isSystem:0},{name:`Sewa Tempat`,type:`expense`,isSystem:0},{name:`Listrik & Air`,type:`expense`,isSystem:0},{name:`Operasional`,type:`expense`,isSystem:0},{name:`Lain-lain`,type:`expense`,isSystem:0}];async function A(e){let t=o();for(let n=0;n<k.length;n++){let r=k[n];(await e.query(`SELECT id FROM cashflow_categories WHERE name = ? AND deleted_at IS NULL LIMIT 1`,[r.name])).length>0||await e.run(`INSERT INTO cashflow_categories
         (id, name, type, is_system, sort_order, created_at, updated_at, dirty, sync_version)
       VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0)`,[E(),r.name,r.type,r.isSystem,n,t,t])}}var j={version:6,name:`protect-legacy-cashflow-defaults`,up:async e=>{await e.run(`
        WITH canonical_defaults(name, type, is_system, sort_order) AS (
          VALUES
            ('Penjualan', 'income', 1, 0),
            ('Modal / Setoran', 'income', 0, 1),
            ('Pendapatan Lain', 'income', 0, 2),
            ('Belanja Stok', 'expense', 0, 3),
            ('Gaji Karyawan', 'expense', 0, 4),
            ('Sewa Tempat', 'expense', 0, 5),
            ('Listrik & Air', 'expense', 0, 6),
            ('Operasional', 'expense', 0, 7),
            ('Lain-lain', 'expense', 0, 8)
        ),
        complete_seed_cohorts AS (
          SELECT cashflow_categories.created_at
          FROM cashflow_categories
          LEFT JOIN canonical_defaults
            ON canonical_defaults.name = cashflow_categories.name
           AND canonical_defaults.type = cashflow_categories.type
           AND canonical_defaults.is_system = cashflow_categories.is_system
           AND canonical_defaults.sort_order = cashflow_categories.sort_order
          LEFT JOIN outbox
            ON outbox.entity = 'cashflow_categories'
           AND outbox.entity_id = cashflow_categories.id
          GROUP BY cashflow_categories.created_at
          HAVING COUNT(*) = 9
             AND COUNT(canonical_defaults.name) = 9
             AND COUNT(DISTINCT canonical_defaults.name) = 9
             AND SUM(
               CASE
                 WHEN cashflow_categories.dirty = 1
                  AND cashflow_categories.deleted_at IS NULL
                  AND cashflow_categories.sync_version = 0
                  AND cashflow_categories.remote_id IS NULL
                  AND cashflow_categories.created_at = cashflow_categories.updated_at
                  AND outbox.entity_id IS NULL
                 THEN 1
                 ELSE 0
               END
             ) = 9
        )
        UPDATE cashflow_categories
        SET dirty = 0
        WHERE created_at IN (SELECT created_at FROM complete_seed_cohorts)
      `)}},M=`
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  deleted_at INTEGER,
  dirty INTEGER NOT NULL DEFAULT 1,
  sync_version INTEGER NOT NULL DEFAULT 0,
  remote_id TEXT
`,N=[{version:1,name:`initial-schema`,up:async e=>{await e.execute(`
        CREATE TABLE IF NOT EXISTS categories (
          id TEXT PRIMARY KEY NOT NULL,
          name TEXT NOT NULL,
          sort_order INTEGER NOT NULL DEFAULT 0,
          color TEXT,
          ${M}
        );

        CREATE TABLE IF NOT EXISTS products (
          id TEXT PRIMARY KEY NOT NULL,
          category_id TEXT,
          name TEXT NOT NULL,
          sku TEXT,
          barcode TEXT,
          price INTEGER NOT NULL DEFAULT 0,
          cost INTEGER NOT NULL DEFAULT 0,
          track_stock INTEGER NOT NULL DEFAULT 0,
          stock INTEGER NOT NULL DEFAULT 0,
          image_path TEXT,
          active INTEGER NOT NULL DEFAULT 1,
          ${M}
        );

        CREATE TABLE IF NOT EXISTS cashier_sessions (
          id TEXT PRIMARY KEY NOT NULL,
          opened_at INTEGER NOT NULL,
          closed_at INTEGER,
          opening_cash INTEGER NOT NULL DEFAULT 0,
          expected_cash INTEGER NOT NULL DEFAULT 0,
          counted_cash INTEGER,
          difference INTEGER,
          status TEXT NOT NULL DEFAULT 'open',
          opened_by TEXT,
          note TEXT,
          ${M}
        );

        CREATE TABLE IF NOT EXISTS sales (
          id TEXT PRIMARY KEY NOT NULL,
          session_id TEXT,
          number TEXT NOT NULL,
          subtotal INTEGER NOT NULL DEFAULT 0,
          discount INTEGER NOT NULL DEFAULT 0,
          tax INTEGER NOT NULL DEFAULT 0,
          total INTEGER NOT NULL DEFAULT 0,
          paid INTEGER NOT NULL DEFAULT 0,
          change_due INTEGER NOT NULL DEFAULT 0,
          payment_method TEXT NOT NULL DEFAULT 'cash',
          status TEXT NOT NULL DEFAULT 'completed',
          open_bill_label TEXT,
          opened_at INTEGER,
          origin_device_id TEXT,
          sold_at INTEGER,
          ${M}
        );

        CREATE TABLE IF NOT EXISTS sale_items (
          id TEXT PRIMARY KEY NOT NULL,
          sale_id TEXT NOT NULL,
          product_id TEXT,
          name_snapshot TEXT NOT NULL,
          price_snapshot INTEGER NOT NULL DEFAULT 0,
          qty INTEGER NOT NULL DEFAULT 1,
          discount INTEGER NOT NULL DEFAULT 0,
          line_total INTEGER NOT NULL DEFAULT 0,
          ${M}
        );

        CREATE TABLE IF NOT EXISTS cashflow_categories (
          id TEXT PRIMARY KEY NOT NULL,
          name TEXT NOT NULL,
          type TEXT NOT NULL DEFAULT 'expense',
          is_system INTEGER NOT NULL DEFAULT 0,
          sort_order INTEGER NOT NULL DEFAULT 0,
          ${M}
        );

        CREATE TABLE IF NOT EXISTS cashflow_entries (
          id TEXT PRIMARY KEY NOT NULL,
          category_id TEXT,
          session_id TEXT,
          direction TEXT NOT NULL DEFAULT 'debit',
          amount INTEGER NOT NULL DEFAULT 0,
          source TEXT NOT NULL DEFAULT 'manual',
          source_ref TEXT,
          note TEXT,
          occurred_at INTEGER NOT NULL,
          ${M}
        );

        CREATE TABLE IF NOT EXISTS settings (
          key TEXT PRIMARY KEY NOT NULL,
          value TEXT,
          updated_at INTEGER NOT NULL,
          dirty INTEGER NOT NULL DEFAULT 1,
          sync_version INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS outbox (
          id TEXT PRIMARY KEY NOT NULL,
          entity TEXT NOT NULL,
          entity_id TEXT NOT NULL,
          op TEXT NOT NULL,
          payload TEXT NOT NULL,
          created_at INTEGER NOT NULL,
          attempts INTEGER NOT NULL DEFAULT 0,
          last_error TEXT,
          status TEXT NOT NULL DEFAULT 'pending'
        );

        CREATE TABLE IF NOT EXISTS sync_state (
          entity TEXT PRIMARY KEY NOT NULL,
          last_pulled_at INTEGER NOT NULL DEFAULT 0,
          last_pushed_at INTEGER NOT NULL DEFAULT 0
        );

        CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
        CREATE INDEX IF NOT EXISTS idx_products_dirty ON products(dirty);
        CREATE INDEX IF NOT EXISTS idx_sale_items_sale ON sale_items(sale_id);
        CREATE INDEX IF NOT EXISTS idx_sales_session ON sales(session_id, sold_at);
        CREATE INDEX IF NOT EXISTS idx_sales_open ON sales(status, opened_at);
        CREATE INDEX IF NOT EXISTS idx_sales_origin_device ON sales(origin_device_id);
        CREATE INDEX IF NOT EXISTS idx_cashflow_cat ON cashflow_entries(category_id, occurred_at);
        CREATE INDEX IF NOT EXISTS idx_cashflow_session ON cashflow_entries(session_id);
        CREATE INDEX IF NOT EXISTS idx_outbox_status ON outbox(status, created_at);
      `)}},{version:2,name:`seed-defaults`,up:async e=>{await A(e)}},{version:3,name:`media-table`,up:async e=>{await e.execute(`
        CREATE TABLE IF NOT EXISTS media (
          id TEXT PRIMARY KEY NOT NULL,
          mime TEXT NOT NULL DEFAULT 'image/jpeg',
          width INTEGER,
          height INTEGER,
          bytes INTEGER,
          hash TEXT,
          data TEXT,
          remote_url TEXT,
          ${M}
        );

        CREATE INDEX IF NOT EXISTS idx_media_hash ON media(hash);
        CREATE INDEX IF NOT EXISTS idx_media_dirty ON media(dirty);
      `)}},{version:4,name:`product-barcode-type`,up:async e=>{await e.execute(`
        ALTER TABLE products ADD COLUMN barcode_type TEXT NOT NULL DEFAULT 'EAN13';
        CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode);
      `)}},{version:5,name:`sales-open-bills`,up:async e=>{await e.execute(`
        ALTER TABLE sales RENAME TO sales_legacy;
        DROP INDEX IF EXISTS idx_sales_session;

        CREATE TABLE sales (
          id TEXT PRIMARY KEY NOT NULL,
          session_id TEXT,
          number TEXT NOT NULL,
          subtotal INTEGER NOT NULL DEFAULT 0,
          discount INTEGER NOT NULL DEFAULT 0,
          tax INTEGER NOT NULL DEFAULT 0,
          total INTEGER NOT NULL DEFAULT 0,
          paid INTEGER NOT NULL DEFAULT 0,
          change_due INTEGER NOT NULL DEFAULT 0,
          payment_method TEXT NOT NULL DEFAULT 'cash',
          status TEXT NOT NULL DEFAULT 'completed',
          open_bill_label TEXT,
          opened_at INTEGER,
          origin_device_id TEXT,
          sold_at INTEGER,
          ${M}
        );

        INSERT INTO sales (
          id, session_id, number, subtotal, discount, tax, total, paid,
          change_due, payment_method, status, open_bill_label, opened_at,
          origin_device_id, sold_at, created_at, updated_at, deleted_at,
          dirty, sync_version, remote_id
        )
        SELECT
          id, session_id, number, subtotal, discount, tax, total, paid,
          change_due, payment_method, status, NULL, NULL, NULL, sold_at,
          created_at, updated_at, deleted_at, dirty, sync_version, remote_id
        FROM sales_legacy;

        DROP TABLE sales_legacy;
        CREATE INDEX IF NOT EXISTS idx_sales_session ON sales(session_id, sold_at);
        CREATE INDEX IF NOT EXISTS idx_sales_open ON sales(status, opened_at);
        CREATE INDEX IF NOT EXISTS idx_sales_origin_device ON sales(origin_device_id);
      `)}},j,{version:7,name:`butcher-default-categories`,up:async e=>{for(let t of[{name:`اللحوم`,color:`#B91C1C`,sort:0},{name:`الكبد`,color:`#7C2D12`,sort:1},{name:`الوجبات`,color:`#D97706`,sort:2},{name:`المخروج`,color:`#0F766E`,sort:3}]){if((await e.query(`SELECT id FROM categories WHERE name = ? AND deleted_at IS NULL LIMIT 1`,[t.name])).length)continue;let n=crypto.randomUUID(),r=o();await e.run(`INSERT INTO categories (id, name, sort_order, color, created_at, updated_at, deleted_at, dirty, sync_version, remote_id)
           VALUES (?, ?, ?, ?, ?, ?, NULL, 1, 0, NULL)`,[n,t.name,t.sort,t.color,r,r])}}},{version:8,name:`butcher-sale-quantities`,up:async e=>{await e.execute(`
        ALTER TABLE sale_items ADD COLUMN quantity_kind TEXT NOT NULL DEFAULT 'unit';
        ALTER TABLE sale_items ADD COLUMN weight_grams INTEGER;
        ALTER TABLE sale_items ADD COLUMN portion_quarters INTEGER;
        ALTER TABLE sale_items ADD COLUMN unit_label TEXT;
      `)}},{version:9,name:`sale-bank-transfer-details`,up:async e=>{await e.execute(`
        ALTER TABLE sales ADD COLUMN payment_bank TEXT;
        ALTER TABLE sales ADD COLUMN payment_proof_path TEXT;
      `)}}];async function P(e){await e.execute(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY NOT NULL,
      name TEXT NOT NULL,
      applied_at INTEGER NOT NULL
    );
  `);let t=await e.query(`SELECT version FROM schema_migrations`),n=new Set(t.map(e=>e.version));for(let t of N.sort((e,t)=>e.version-t.version))n.has(t.version)||await e.transaction(async e=>{await t.up(e),await e.run(`INSERT INTO schema_migrations (version, name, applied_at) VALUES (?, ?, ?)`,[t.version,t.name,o()])})}var F=`poskacaw`,I=1,L=null,R=null,z=null,B=null,V=t.getPlatform()===`web`;async function H(e){let{defineCustomElements:t}=await n(async()=>{let{defineCustomElements:e}=await import(`./loader-BBfSJ8Qr.js`);return{defineCustomElements:e}},__vite__mapDeps([2,3]));t(window);let r=document.querySelector(`jeep-sqlite`);r||(r=document.createElement(`jeep-sqlite`),document.body.appendChild(r)),await customElements.whenDefined(`jeep-sqlite`),await e.initWebStore()}var U=class e{conn;inTx;constructor(e,t=!1){this.conn=e,this.inTx=t}get inTransaction(){return this.inTx}async query(e,t=[]){return(await this.conn.query(e,t)).values??[]}async run(e,t=[]){let n=await this.conn.run(e,t,!1);return{changes:n.changes?.changes??0,lastId:n.changes?.lastId}}async execute(e){await this.conn.execute(e,!1)}async transaction(t){if(this.inTx)return t(this);let n=new e(this.conn,!0);await this.conn.beginTransaction();try{let e=await t(n);return await this.conn.isTransactionActive()&&await this.conn.commitTransaction(),e}catch(e){throw await this.conn.isTransactionActive()&&await this.conn.rollbackTransaction(),e}}};async function W(){return z||B||(B=(async()=>(L=new r(a),V&&await H(L),R=(await L.isConnection(F,!1)).result?await L.retrieveConnection(F,!1):await L.createConnection(F,!1,`no-encryption`,I,!1),await R.open(),z=new U(R),await P(z),await A(z),V&&await L.saveToStore(F),z))(),B)}function G(){if(!z)throw Error(`DB belum diinisialisasi — panggil initDb() dulu di main.ts`);return z}async function K(){V&&L&&await L.saveToStore(F)}async function q(){R&&await R.close(),L&&await L.closeConnection(F,!1),z=null,R=null,L=null,B=null}export{A as a,E as c,u as d,d as f,a as g,p as h,K as i,h as l,o as m,G as n,O as o,f as p,W as r,D as s,q as t,m as u};