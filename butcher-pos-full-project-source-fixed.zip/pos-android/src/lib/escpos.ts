import type { ReceiptJob, ReceiptLine } from '@/services/capabilities/registry'

/**
 * Render Arabic receipts as a monochrome raster image. Thermal printers use
 * single-byte code pages for text and cannot reliably decode UTF-8 Arabic.
 * Raster output keeps Arabic shaping, RTL order, punctuation and numerals as
 * rendered by the Android WebView.
 */
export interface EscposOpts {
  feed?: number
  cut?: boolean
  pixelWidth?: 384 | 576
}

function wrapLine(ctx: CanvasRenderingContext2D, line: ReceiptLine, maxWidth: number): string[] {
  const source = line.text ?? ''
  if (!source) return ['']
  const words = source.split(/\s+/)
  const output: string[] = []
  let current = ''
  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word
    if (current && ctx.measureText(candidate).width > maxWidth) {
      output.push(current)
      current = word
    } else {
      current = candidate
    }
  }
  if (current) output.push(current)
  return output
}

function rasterize(job: ReceiptJob, width: number): { data: Uint8Array; rowBytes: number; height: number } {
  const padding = 10
  const maxTextWidth = width - padding * 2
  const canvas = document.createElement('canvas')
  const ctx = canvas.getContext('2d', { willReadFrequently: true })
  if (!ctx) throw new Error('تعذر تجهيز صورة الفاتورة للطباعة.')

  const prepared: Array<{ line: ReceiptLine; text: string; fontSize: number; lineHeight: number }> = []
  let totalHeight = padding * 2
  for (const line of job.lines) {
    const fontSize = line.size === 'large' ? 30 : 23
    const lineHeight = line.size === 'large' ? 42 : 32
    ctx.font = `${line.bold ? 'bold ' : ''}${fontSize}px sans-serif`
    const wrapped = wrapLine(ctx, line, maxTextWidth)
    for (const text of wrapped) {
      prepared.push({ line, text, fontSize, lineHeight })
      totalHeight += lineHeight
    }
  }

  canvas.width = width
  canvas.height = Math.max(totalHeight, 64)
  ctx.fillStyle = '#ffffff'
  ctx.fillRect(0, 0, width, canvas.height)
  ctx.fillStyle = '#000000'
  ctx.textBaseline = 'middle'
  ctx.direction = 'rtl'

  let y = padding
  for (const item of prepared) {
    ctx.font = `${item.line.bold ? 'bold ' : ''}${item.fontSize}px sans-serif`
    ctx.textAlign = item.line.align === 'center'
      ? 'center'
      : item.line.align === 'right' ? 'right' : 'left'
    const x = item.line.align === 'center'
      ? width / 2
      : item.line.align === 'right' ? width - padding : padding
    ctx.fillText(item.text, x, y + item.lineHeight / 2, maxTextWidth)
    y += item.lineHeight
  }

  const pixels = ctx.getImageData(0, 0, width, canvas.height).data
  const rowBytes = Math.ceil(width / 8)
  const raster = new Uint8Array(rowBytes * canvas.height)
  for (let py = 0; py < canvas.height; py++) {
    for (let px = 0; px < width; px++) {
      const i = (py * width + px) * 4
      const luminance = (pixels[i] * 299 + pixels[i + 1] * 587 + pixels[i + 2] * 114) / 1000
      if (luminance < 180) raster[py * rowBytes + (px >> 3)] |= 0x80 >> (px & 7)
    }
  }
  return { data: raster, rowBytes, height: canvas.height }
}

export function encodeReceipt(job: ReceiptJob, opts: EscposOpts = {}): Uint8Array {
  const bytes: number[] = []
  const push = (...values: number[]) => bytes.push(...values)
  const width = opts.pixelWidth ?? job.pixelWidth ?? 384

  push(0x1b, 0x40) // ESC @
  push(0x1b, 0x61, 0x00) // left alignment for raster
  const image = rasterize(job, width)

  // GS v 0 — print raster bit image (little-endian byte width and height).
  push(
    0x1d, 0x76, 0x30, 0x00,
    image.rowBytes & 0xff, (image.rowBytes >> 8) & 0xff,
    image.height & 0xff, (image.height >> 8) & 0xff,
  )
  for (const value of image.data) bytes.push(value)

  push(0x1b, 0x40)
  const feed = opts.feed ?? 3
  for (let i = 0; i < feed; i++) push(0x0a)
  if (opts.cut ?? true) push(0x1d, 0x56, 0x01)
  return Uint8Array.from(bytes)
}
