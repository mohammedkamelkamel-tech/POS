<script setup lang="ts">
import { onMounted, computed } from 'vue'
import { RouterLink, useRoute } from 'vue-router'
import { storeToRefs } from 'pinia'
import { cn } from '@/lib/utils'
import { useSettingsStore } from '@/stores/settings'
import { useAuthStore } from '@/stores/auth'
import { useMediaStore } from '@/stores/media'
import { navItems, isNavActive } from './navItems'

const route = useRoute()
const settings = useSettingsStore()
const media = useMediaStore()
const auth = useAuthStore()
const visibleNavItems = computed(() => auth.isOwner ? navItems : navItems.filter(item => item.to === '/' || item.to === '/pos'))
const { storeName, storeOwner, storeLogo } = storeToRefs(settings)

onMounted(() => {
  if (storeLogo.value) media.ensure([storeLogo.value])
})
</script>

<template>
  <aside
    class="hidden w-64 shrink-0 flex-col border-r border-border bg-card md:flex"
  >
    <!-- Profil toko -->
    <RouterLink
      to="/"
      class="flex items-center gap-3 border-b border-border px-4 py-4 pt-[max(1rem,env(safe-area-inset-top))]"
    >
      <div
        class="flex size-10 items-center justify-center overflow-hidden rounded-xl bg-primary/10 text-primary"
      >
        <img
          v-if="media.url(storeLogo)"
          :src="media.url(storeLogo)!"
          alt="شعار المتجر"
          class="size-full object-contain p-0.5"
        />
        <img
          v-else
          src="/alkamel-cashier-logo.jpg"
          alt="شعار الكامل-كاشير"
          class="size-full object-contain"
        />
      </div>
      <div class="min-w-0">
        <p class="truncate text-sm font-bold leading-tight">{{ storeName }}</p>
        <p class="truncate text-xs text-muted-foreground">
          {{ storeOwner || 'الكامل-كاشير' }}
        </p>
      </div>
    </RouterLink>

    <!-- Menu -->
    <nav class="no-scrollbar flex-1 space-y-1 overflow-y-auto p-3">
      <RouterLink
        v-for="item in visibleNavItems"
        :key="item.to"
        :to="item.to"
        class="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-colors"
        :class="
          cn(
            isNavActive(route.path, item)
              ? 'bg-primary/10 font-semibold text-primary'
              : 'text-muted-foreground hover:bg-accent hover:text-foreground',
          )
        "
      >
        <component :is="item.icon" class="size-5 shrink-0" />
        <span class="truncate">{{ item.label }}</span>
      </RouterLink>
    </nav>
  </aside>
</template>
